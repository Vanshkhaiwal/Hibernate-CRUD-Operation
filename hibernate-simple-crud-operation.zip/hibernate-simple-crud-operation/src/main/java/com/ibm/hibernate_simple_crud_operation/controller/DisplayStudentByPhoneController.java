package com.ibm.hibernate_simple_crud_operation.controller;

import com.ibm.hibernate_simple_crud_operation.dao.StudentDao;
import com.ibm.hibernate_simple_crud_operation.entity.Student;

public class DisplayStudentByPhoneController {

	public static void main(String[] args) {
		
//		Student student=new StudentDao().fetchStudentByPhoneDao(6667543);
		
		boolean b=new StudentDao().deleteStudentByNameDao("Harshit");
		
		if (b) {
			System.out.println("deleted");
		} else {
			System.out.println("check your code or given name is not present");
		}
	}
}
