package com.ibm.hibernate_simple_crud_operation.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;


@Data
@Entity
public class Student {

    @Id	
	private int id;
	private String name;
	private String email;
	private String password;
	private long phone;
	private LocalDate dob;
		
	
}
