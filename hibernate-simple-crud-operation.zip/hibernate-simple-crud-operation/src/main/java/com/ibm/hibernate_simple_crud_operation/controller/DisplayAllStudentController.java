package com.ibm.hibernate_simple_crud_operation.controller;

import java.util.List;

import com.ibm.hibernate_simple_crud_operation.dao.StudentDao;
import com.ibm.hibernate_simple_crud_operation.entity.Student;

public class DisplayAllStudentController {

	public static void main(String[] args) {
		
		List<Student> students=new StudentDao().fetchAllStudentDao();
		
		if(!students.isEmpty()) {
			
			for (Student student : students) {
				System.out.println(student);
			}
			
		}
	}
}
