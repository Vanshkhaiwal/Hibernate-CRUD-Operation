package com.ibm.hibernate_simple_crud_operation.controller;

import com.ibm.hibernate_simple_crud_operation.dao.StudentDao;

public class DeleteStudentByIdController {

	public static void main(String[] args) {
		
		boolean b=new StudentDao().deleteStudentByIdDao(89890);
		
		String msg = b?"deleted":"check with your id or if id is correct check your code";
		
		System.out.println(msg);
	}
}
