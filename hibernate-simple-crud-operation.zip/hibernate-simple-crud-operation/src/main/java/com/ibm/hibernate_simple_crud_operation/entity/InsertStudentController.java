package com.ibm.hibernate_simple_crud_operation.entity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class InsertStudentController {

	 public static void main(String[] args) {
	        Connection con = null;
	        Statement stmt = null;

	        try {
	            // 1. Load Oracle JDBC Driver
	            Class.forName("oracle.jdbc.driver.OracleDriver");

	            // 2. Create Connection
	            con = DriverManager.getConnection(
	                "jdbc:oracle:thin:@localhost:1521:xe", // change if needed
	                "SYSTEM",
	                "Mazhar@123"
	            );

	            // 3. Create Statement
	            stmt = con.createStatement();

	            // 4. SQL Insert Query
	            String sql = "INSERT INTO student (id, name, email) " +
	                         "VALUES (2, 'John Doe', 'john@example.com')";

	            // 5. Execute Insert
	            int rows = stmt.executeUpdate(sql);

	            System.out.println(rows + " row(s) inserted.");

	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                if (stmt != null) stmt.close();
	                if (con != null) con.close();
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	    }
}
