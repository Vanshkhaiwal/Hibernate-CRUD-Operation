package com.ibm.hibernate_simple_crud_operation.dao;

import java.util.List;

import com.ibm.hibernate_simple_crud_operation.entity.Student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class StudentDao {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("hibernate");

	EntityManager em = null;
	EntityTransaction et = null;

	public Student saveStudentDao(Student student) {

		em = emf.createEntityManager();
		et = em.getTransaction();

		et.begin();
		em.persist(student);
		et.commit();

		return student;
	}

	public Student getStudentByIdDao(int id) {

		em = emf.createEntityManager();

		return em.find(Student.class, id);

	}

	public boolean deleteStudentByIdDao(int studentId) {

		em = emf.createEntityManager();

		et = em.getTransaction();

		Student student = em.find(Student.class, studentId);

		if (student != null) {

			et.begin();
			em.remove(student);
			et.commit();
			return true;
		}

		return false;
	}

	public boolean updateStudentByIdDao(int studentId, String studentName) {

		em = emf.createEntityManager();

		et = em.getTransaction();

		Student student = em.find(Student.class, studentId);

		if (student != null) {

			student.setName(studentName);

			et.begin();
			em.merge(student);
			et.commit();
			return true;
		}

		return false;
	}

	public List<Student> fetchAllStudentDao() {

		em = emf.createEntityManager();

		String displayStudentQuery = "FROM Student";

		Query query = em.createQuery(displayStudentQuery);

		return query.getResultList();
	}

	public Student fetchStudentByEmailDao(String email) {

		try {
			String displayStudentByEmailQuery = "SELECT s FROM Student s where s.email=?1";

			em = emf.createEntityManager();

			Query query = em.createQuery(displayStudentByEmailQuery, Student.class);

			query.setParameter(1, email);

			Student student = (Student) query.getSingleResult();

			return student;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public Student fetchStudentByPhoneDao(long phone) {

		em = emf.createEntityManager();

		try {
			String displayStudentByPhoneQuery = "SELECT * from student where phone = ?1";

			Query query = em.createNativeQuery(displayStudentByPhoneQuery, Student.class);

			query.setParameter(1, phone);

			Student student = (Student) query.getSingleResult();

			return student;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public boolean deleteStudentByNameDao(String name) {

		em = emf.createEntityManager();

		et = em.getTransaction();
		try {
			String deleteStudentByNameQuery = "DELETE from Student s where s.name=:studentName";

			Query query = em.createQuery(deleteStudentByNameQuery);

			query.setParameter("studentName", name);

			
			et.begin();
			int a=query.executeUpdate();
			et.commit();
			
			System.out.println("no of row deleted = "+a);
			
			return true;
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}
}
