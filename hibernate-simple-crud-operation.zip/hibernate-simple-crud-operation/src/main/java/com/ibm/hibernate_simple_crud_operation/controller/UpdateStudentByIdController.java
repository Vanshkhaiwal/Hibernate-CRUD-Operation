package com.ibm.hibernate_simple_crud_operation.controller;

import com.ibm.hibernate_simple_crud_operation.dao.StudentDao;

public class UpdateStudentByIdController {

	public static void main(String[] args) {
		
		boolean b = new StudentDao().updateStudentByIdDao(9999, "Ankit-Sharma");
		
		String msg = b ? "updated" : "check with your id or if id is correct check your code";

		System.out.println(msg);
	}
}
