package com.ibm.hibernate_simple_crud_operation.controller;

import com.ibm.hibernate_simple_crud_operation.dao.StudentDao;
import com.ibm.hibernate_simple_crud_operation.entity.Student;

public class GetStudentByEmailController {

	public static void main(String[] args) {

		Student student = new StudentDao().fetchStudentByEmailDao("ankit@gmail.com");

		if (student != null) {
			System.out.println(student);
		} else {
			System.out.println("check your code or given email is not present");
		}
	}
}
