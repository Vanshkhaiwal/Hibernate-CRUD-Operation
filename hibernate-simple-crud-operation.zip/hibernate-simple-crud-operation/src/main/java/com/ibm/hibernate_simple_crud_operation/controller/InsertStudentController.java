package com.ibm.hibernate_simple_crud_operation.controller;

import java.time.LocalDate;

import com.ibm.hibernate_simple_crud_operation.dao.StudentDao;
import com.ibm.hibernate_simple_crud_operation.entity.Student;

public class InsertStudentController {

	public static void main(String[] args) {
		
		Student  student = new Student();
		
		student.setId(9999);
		student.setName("ankit");
		student.setEmail("ankit@gmail.com");
		student.setPhone(6667543);
		student.setPassword("ankit7890");
		student.setDob(LocalDate.parse("1997-09-13"));
		
		new StudentDao().saveStudentDao(student);
	}
}
